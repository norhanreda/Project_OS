
 struct process
{
	int id;			
	int arrival;
	int runtime;
	int priority;	 
	
};

